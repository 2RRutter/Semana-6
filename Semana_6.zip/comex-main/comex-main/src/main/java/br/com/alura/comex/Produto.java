package br.com.alura.comex;

import java.util.Objects;

public class Produto {

   private String nome;
   private String descricao;
   private double precoUnitario;
   private int quantidade;

    @Override
    public String toString (){
        return "Produto: nome= " + this.nome + ", descricao= " + this.descricao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Produto produto = (Produto) o;
        return Double.compare(precoUnitario, produto.precoUnitario) == 0 && quantidade == produto.quantidade && Objects.equals(nome, produto.nome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, precoUnitario, quantidade);
    }
}

