package br.com.alura.comex;

public class TestaProduto {

    public static void main(String[] args) {

        Produto celular = new Produto();
        celular.setNome("Xiaomi 500");
        celular.setQuantidade(1);
        celular.setDescricao("XYZ");
        celular.setPrecoUnitario(2800);

        Produto geladeira = new Produto();
        geladeira.setNome("Filmadora BBZ");
        geladeira.setQuantidade(1);
        geladeira.setDescricao("XPTO");
        geladeira.setPrecoUnitario(4800);

        System.out.println(celular);
        System.out.println(geladeira);

        if (celular == geladeira)
        System.out.println("são iguais");
        else System.out.println("São diferentes");

    }

}


